/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package chatroom;

import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author ecampana
 */
public class Chatroom {


    
    public static void main(String[] args) {
        
    try
        {
            //Creates Server on this Socket
            ServerSocket s = new ServerSocket(8189);
            boolean over = false;
            String linein = "Please Begin the Chat!";
            
            while(!over)
            {
                Socket incoming = s.accept();
                    InputStream inStream = incoming.getInputStream();
                    OutputStream outStream = incoming.getOutputStream();
                    Scanner in = new Scanner(inStream);
                    PrintWriter out = new PrintWriter(outStream,true);
                    PrintWriter write = new PrintWriter(new FileWriter("log.txt",true));
                boolean done = false;  
                out.println(linein.trim());
               
                while(!done && in.hasNextLine()){
                linein = in.nextLine();
                  System.out.println(linein.trim());
                  write.println(linein.trim());
                  write.flush();
                   if (linein.trim().contains("END")){
                   write.println("Server is Ending Goodbye :)");
                    write.flush();
                     done = true;
                     over = true;        
                    
                  }

                  out.println(linein.trim());
                 

                }
               
                    
                   

                    
              
            }
        }
        catch(Exception exc2)
        {
            exc2.printStackTrace();
        }
        
        
        
       
        
    }
}   